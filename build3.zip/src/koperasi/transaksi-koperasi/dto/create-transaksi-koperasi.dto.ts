export class CreateTransaksiKoperasiDto {}
