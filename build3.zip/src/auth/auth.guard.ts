import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private jwtService: JwtService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const token = this.extractTokenFromHeader(request);
    
    if (!token) {
      throw new UnauthorizedException('Akses ditolak: Token tidak ditemukan');
    }

    try {
      const payload = await this.jwtService.verifyAsync(token);
      request['user'] = payload;
      
    } catch {
      throw new UnauthorizedException('Akses ditolak: Token tidak valid atau kadaluwarsa');
    }return true;
  }

  // Fungsi bantuan untuk mengambil teks token dari format "Bearer <token>"
  private extractTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}