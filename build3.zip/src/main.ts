import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({
    origin: [
      'https://klabatmandiri.com',     
      'http://localhost:9000',          
      'http://localhost:3000'
    ],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true, // Izinkan jika kamu mengirim cookie/authorization header
  });
  await app.listen(process.env.PORT || 3000);
}

bootstrap();